```
:root{--rose:#f6c6d6;--blush:#fde3ea;--cream:#fff6e8;--lav:#cdb8ee;--gold:#d9b46a;--ink:#5a3550;--night:#2b2a5e}
*{box-sizing:border-box}
html,body{height:100%;margin:0;overflow:hidden;background:var(--night);color:var(--ink);font-family:"Palatino Linotype",Palatino,"Book Antiqua",Georgia,serif}
button{font:inherit;color:inherit;cursor:pointer}
:focus-visible{outline:3px solid var(--gold);outline-offset:3px}
#app{height:100dvh;display:flex;flex-direction:column;position:relative}
#bar{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:6px 12px;background:#2b2a5ecc;color:var(--cream);font-size:.95rem;z-index:5}
#bar span{display:flex;gap:6px;align-items:center}
#bar button,#bar a{background:#ffffff1f;border:1px solid #ffffff44;color:var(--cream);border-radius:999px;padding:4px 11px;font-size:.82rem;text-decoration:none}
#scene{flex:1;min-height:0;position:relative;overflow:hidden;background:linear-gradient(#2b2a5e,#d79ac0)}
#art,#art svg{position:absolute;inset:0;width:100%;height:100%}
#art svg{overflow:visible}
#panel{background:linear-gradient(var(--cream),#fbe3d3);border-top:3px solid var(--gold);border-radius:20px 20px 0 0;padding:14px 20px 18px;max-height:44vh;overflow:auto;box-shadow:0 -10px 30px #0006;position:relative;z-index:3}
#panel h1{margin:0 0 6px;font-size:1.3rem;font-weight:700;letter-spacing:.01em}
#px{margin:0 0 8px;line-height:1.55;max-width:68ch;animation:fadeup .8s both}
#nar{margin:6px 0;padding:8px 12px;border-left:4px solid var(--rose);background:#fff;border-radius:0 12px 12px 0;font-style:italic;min-height:0;white-space:pre-wrap}
#nar:empty{display:none}
#ch{display:flex;flex-direction:column;gap:7px;margin-top:8px}
.choice{text-align:left;background:#fff;border:2px solid var(--rose);border-radius:14px;padding:9px 14px;transition:transform .15s,border-color .15s}
.choice:hover{transform:translateX(4px);border-color:var(--gold)}
.choice.lock{opacity:.55;border-style:dashed}
/* objects */
.obj{cursor:pointer;outline:none}
.obj .g{transition:transform .3s,filter .3s;transform-box:fill-box;transform-origin:center}
.obj:hover .g,.obj:focus-visible .g{filter:drop-shadow(0 0 10px #ffe6a8);transform:scale(1.1)}
.obj .cue{fill:#ffe6a8;animation:pulse 2.6s infinite}
.obj.used .cue{display:none}
.obj.used .g{animation:bloom .8s}
.react .sw{animation-duration:.5s!important}
.react{animation:shake .5s}
/* ambient animation */
.tw{animation:tw 3s infinite ease-in-out}
.sw{transform-box:fill-box;transform-origin:50% 100%;animation:sway 4s infinite ease-in-out}
.bob{animation:bob 6s infinite ease-in-out}
.pg{animation:bob 5s infinite ease-in-out}
.ff{animation:ff 9s infinite ease-in-out}
.bf{transform-box:fill-box;transform-origin:center;animation:flap .5s infinite alternate ease-in-out}
.dd{transform-box:fill-box}
.bl{transform-box:fill-box;transform-origin:center;animation:blink 6s infinite}
.fs{animation:swim 7s infinite ease-in-out}
.rp{transform-box:fill-box;transform-origin:center;animation:rip 4s infinite}
.drift{animation:drift 30s infinite ease-in-out alternate}
.gl{animation:tw 2.4s infinite}
.tl{transform-box:fill-box;transform-origin:0 100%;animation:sway 3s infinite}
.peek{animation:peek 12s infinite ease-in-out}
/* kitten */
#kit{position:absolute;right:10px;bottom:6px;width:84px;height:84px;background:none;border:0;padding:0;z-index:4}
#kit svg{width:100%;height:100%;overflow:visible}
#kit .tail{transform-box:fill-box;transform-origin:0 100%;animation:sway 2.4s infinite ease-in-out}
#kit .bd{transform-box:fill-box;transform-origin:50% 100%;animation:breathe 3.4s infinite ease-in-out}
#kit .eye{transform-box:fill-box;transform-origin:center;animation:blink 5s infinite}
#kit .pu{transform:translate(var(--px,0),var(--py,0));transition:transform .2s}
#kit.sleep .eye{transform:scaleY(.12);animation:none}
#kit.sleep .tail{animation-duration:6s}
#kit.hop{animation:hop .6s}
#kit.happy .tail{animation-duration:.35s}
#kb{position:absolute;right:98px;bottom:18px;max-width:min(300px,62vw);background:#fff;border:2px solid var(--rose);border-radius:16px 16px 4px 16px;padding:9px 13px;font-size:.92rem;line-height:1.4;z-index:4;opacity:0;transform:translateY(8px);pointer-events:none;transition:.3s;box-shadow:0 6px 20px #0003}
#kb.on{opacity:1;transform:none}
/* modal */
#modal{position:fixed;inset:0;background:#1b1a4acc;display:flex;align-items:center;justify-content:center;z-index:20;padding:16px}
#modal[hidden]{display:none}
.card{background:linear-gradient(var(--cream),#fbe3d3);border:3px solid var(--gold);border-radius:22px;padding:22px;max-width:520px;width:100%;max-height:86vh;overflow:auto;box-shadow:0 20px 60px #0008;animation:fadeup .5s both}
.card h2{margin:0 0 10px}
.card p{line-height:1.55;white-space:pre-wrap}
.card input{width:100%;font:inherit;padding:10px;border:2px solid var(--rose);border-radius:12px;margin:6px 0}
.card .row{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
.card button{background:#fff;border:2px solid var(--rose);border-radius:12px;padding:8px 14px}
.card button.pri{background:var(--rose);font-weight:700}
.card .pick{background:var(--blush)}
.shake{animation:shake .4s}
.cl{padding:5px 0;border-bottom:1px dashed var(--rose)}
#tr{position:fixed;inset:0;z-index:30;pointer-events:none;display:none}
#tr .pt{position:absolute;width:26px;height:14px;border-radius:70% 0 70% 0;opacity:.9}
@keyframes tw{50%{opacity:.25}}
@keyframes sway{50%{transform:rotate(4deg)}0%,100%{transform:rotate(-4deg)}}
@keyframes bob{50%{transform:translateY(-12px)}}
@keyframes ff{0%,100%{transform:translate(0,0)}33%{transform:translate(30px,-26px)}66%{transform:translate(-24px,-10px)}}
@keyframes flap{to{transform:scaleX(.55)}}
@keyframes blink{0%,92%,100%{transform:scaleY(1)}95%{transform:scaleY(.1)}}
@keyframes swim{50%{transform:translateX(70px) scaleX(1)}25%{transform:translateX(35px) rotate(4deg)}75%{transform:translateX(35px) rotate(-4deg)}}
@keyframes rip{0%{transform:scale(.3);opacity:.9}100%{transform:scale(2.2);opacity:0}}
@keyframes drift{to{transform:translateX(90px)}}
@keyframes peek{0%,60%,100%{transform:translateY(40px)}70%,90%{transform:none}}
@keyframes breathe{50%{transform:scaleY(1.04)}}
@keyframes hop{40%{transform:translateY(-22px)}}
@keyframes pulse{50%{opacity:.2;transform:translateY(-4px)}}
@keyframes bloom{40%{transform:scale(1.35)}}
@keyframes shake{25%{transform:translateX(-6px)}75%{transform:translateX(6px)}}
@keyframes fadeup{from{opacity:0;transform:translateY(10px)}}
@media(max-width:600px){#panel{padding:12px 14px 16px}#kit{width:70px;height:70px}#kb{right:84px}}
@media(prefers-reduced-motion:reduce){*,*::before,*::after{animation:none!important;transition:none!important}}
```
